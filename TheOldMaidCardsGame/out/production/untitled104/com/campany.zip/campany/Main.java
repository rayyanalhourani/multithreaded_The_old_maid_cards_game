package com.campany;

import com.campany.game.Game;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Game game = new Game();
        game.startGame();
    }
}

